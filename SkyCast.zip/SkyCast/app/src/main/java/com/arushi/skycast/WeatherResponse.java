package com.arushi.skycast; // same package as WeatherAPI.java;ensures all related files remain in the same project

import com.google.gson.annotations.SerializedName; //used to convert json to java variable

public class WeatherResponse { //main class
    @SerializedName("name")
    public String cityName;

    @SerializedName("main")
    public Main main;

    public class Main {
        @SerializedName("temp")
        public float temperature;
    }
}
