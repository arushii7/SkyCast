package com.arushi.skycast;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText etCity;
    private Button btnSearch, btnSuggestSongs;
    private TextView tvTemperature, tvWeather, tvHumidity, tvWindSpeed, tvMood, tvSuggestedSongs;
    private SeekBar seekBarMood;

    private String[] songs_sunny_happy = {"Yellow - Coldplay", "Can't Stop the Feeling - Justin Timberlake", "Happy - Pharrell", "Uptown Funk - Mark Ronson", "I'm Yours - Jason Mraz"};
    private String[] songs_sunny_neutral = {"Budapest - George Ezra", "Somewhere Only We Know - Keane", "Take Me to Church - Hozier", "Stand By Me - Ben E. King", "Gravity - John Mayer"};
    private String[] songs_sunny_sad = {"The Scientist - Coldplay", "Let Her Go - Passenger", "Fix You - Coldplay", "Hurt - Johnny Cash", "Someone Like You - Adele"};
    private String[] songs_rainy_happy = {"Raindrops Keep Fallin' On My Head - B.J. Thomas", "I'm Singing in the Rain - Gene Kelly", "Rihanna - Umbrella", "It's Raining Men - The Weather Girls", "Banana Pancakes - Jack Johnson"};
    private String[] songs_rainy_neutral = {"Set Fire to the Rain - Adele", "November Rain - Guns N' Roses", "Creep - Radiohead", "The Rain Song - Led Zeppelin", "The Rain - Missy Elliott"};
    private String[] songs_rainy_sad = {"The Sound of Silence - Simon & Garfunkel", "Tears in Heaven - Eric Clapton", "How to Save a Life - The Fray", "Breathe Me - Sia", "Don't Let the Sun Go Down On Me - Elton John"};
    private String[] songs_cloudy_happy = {"Here Comes the Sun - The Beatles", "Ain't No Mountain High Enough - Marvin Gaye", "Dreams - Fleetwood Mac", "You Make My Dreams - Hall & Oates", "What a Wonderful World - Louis Armstrong"};
    private String[] songs_cloudy_neutral = {"Viva La Vida - Coldplay", "The Middle - Zedd", "Chasing Cars - Snow Patrol", "Let It Be - The Beatles", "Blackbird - The Beatles"};
    private String[] songs_cloudy_sad = {"Wish You Were Here - Pink Floyd", "Hallelujah - Jeff Buckley", "Mad World - Gary Jules", "The Night We Met - Lord Huron", "My Immortal - Evanescence"};

    private String currentWeather;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Allow network requests in main thread (not recommended, but quick fix)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // Initialize UI elements
        etCity = findViewById(R.id.etCity);
        btnSearch = findViewById(R.id.btnSearch);
        btnSuggestSongs = findViewById(R.id.btnSuggestSongs);
        tvTemperature = findViewById(R.id.tvTemperature);
        tvWeather = findViewById(R.id.tvWeather);
        tvHumidity = findViewById(R.id.tvHumidity);
        tvWindSpeed = findViewById(R.id.tvWindSpeed);
        tvMood = findViewById(R.id.tvMood);
        tvSuggestedSongs = findViewById(R.id.tvSuggestedSongs);
        seekBarMood = findViewById(R.id.seekBarMood);

        btnSearch.setOnClickListener(v -> {
            String city = etCity.getText().toString().trim();
            if (!city.isEmpty()) {
                fetchWeather(city);
            } else {
                Toast.makeText(MainActivity.this, "Enter a city name", Toast.LENGTH_SHORT).show();
            }
        });

        seekBarMood.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                String mood = "";
                switch (progress) {
                    case 0: mood = "Sad"; break;
                    case 1: mood = "Neutral"; break;
                    case 2: mood = "Happy"; break;
                }
                tvMood.setText("Mood: " + mood);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnSuggestSongs.setOnClickListener(v -> suggestSongs());
    }

    private void fetchWeather(String city) {
        String apiKey = "893dbfc164420eac102a3496c2eebf3c"; // 🔴 Replace with your actual OpenWeather API key
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONObject main = response.getJSONObject("main");
                        double temp = main.getDouble("temp");
                        int humidity = main.getInt("humidity");

                        JSONArray weatherArray = response.getJSONArray("weather");
                        currentWeather = weatherArray.getJSONObject(0).getString("description");

                        JSONObject wind = response.getJSONObject("wind");
                        double windSpeed = wind.has("speed") ? wind.getDouble("speed") : 0.0;

                        // Update UI with fetched data
                        tvTemperature.setText("Temperature: " + temp + "°C");
                        tvWeather.setText("Weather: " + currentWeather);
                        tvHumidity.setText("Humidity: " + humidity + "%");
                        tvWindSpeed.setText("Wind Speed: " + windSpeed + " m/s");

                        // Show the Suggest Songs button after weather fetch
                        btnSuggestSongs.setVisibility(View.VISIBLE);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error parsing weather data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(MainActivity.this, "Failed to get data", Toast.LENGTH_SHORT).show());

        queue.add(request);
    }

    private void suggestSongs() {
        int moodProgress = seekBarMood.getProgress();
        String mood = "";
        switch (moodProgress) {
            case 0: mood = "Sad"; break;
            case 1: mood = "Neutral"; break;
            case 2: mood = "Happy"; break;
        }

        String[] songsToDisplay = new String[0];

        // Based on weather and mood, pick the correct songs
        if (currentWeather.contains("clear") && mood.equals("Happy")) {
            songsToDisplay = songs_sunny_happy;
        } else if (currentWeather.contains("clear") && mood.equals("Neutral")) {
            songsToDisplay = songs_sunny_neutral;
        } else if (currentWeather.contains("clear") && mood.equals("Sad")) {
            songsToDisplay = songs_sunny_sad;
        } else if (currentWeather.contains("rain") && mood.equals("Happy")) {
            songsToDisplay = songs_rainy_happy;
        } else if (currentWeather.contains("rain") && mood.equals("Neutral")) {
            songsToDisplay = songs_rainy_neutral;
        } else if (currentWeather.contains("rain") && mood.equals("Sad")) {
            songsToDisplay = songs_rainy_sad;
        } else if (currentWeather.contains("cloud") && mood.equals("Happy")) {
            songsToDisplay = songs_cloudy_happy;
        } else if (currentWeather.contains("cloud") && mood.equals("Neutral")) {
            songsToDisplay = songs_cloudy_neutral;
        } else if (currentWeather.contains("cloud") && mood.equals("Sad")) {
            songsToDisplay = songs_cloudy_sad;
        }

        // Display the songs in the TextView
        StringBuilder songList = new StringBuilder();
        for (String song : songsToDisplay) {
            songList.append(song).append("\n");
        }
        tvSuggestedSongs.setText(songList.toString());
    }
}
